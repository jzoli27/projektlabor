package com.example.okoslista;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.okoslista.modells.Listmodell;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class List_manipulation extends AppCompatActivity implements Listadapter.OnNoteListener {
    FloatingActionButton newlistbtn;

    RecyclerView listrecyclerview;
    DatabaseReference database;
    Listadapter listadapter;
    ArrayList<Listmodell> list;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_manipulation);

        listrecyclerview = findViewById(R.id.listRv);
        database = FirebaseDatabase.getInstance().getReference("Lists");
        listrecyclerview.setHasFixedSize(true);
        listrecyclerview.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        listadapter = new Listadapter(this,list,this);
        listrecyclerview.setAdapter(listadapter);

        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Listmodell listmodell = dataSnapshot.getValue(Listmodell.class);
                    list.add(listmodell);
                }
                listadapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        newlistbtn = findViewById(R.id.newlistBtn);

        newlistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(List_manipulation.this,Newlist.class));
            }
        });
    }

    @Override
    public void onNoteClick(int position) {
        //list.get(position);
        //Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        //startActivity(intent);
        String listid = list.get(position).getListid();
        Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        intent.putExtra("listid",listid);
        startActivity(intent);
        Log.d("teszt","onNoteClick is clicked. " + list.get(position).getName());
    }
}
