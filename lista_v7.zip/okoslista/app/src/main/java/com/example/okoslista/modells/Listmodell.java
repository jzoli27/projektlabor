package com.example.okoslista.modells;

public class Listmodell {
    private String name, listid;

    public Listmodell() {

    }

    public Listmodell(String name, String listid) {
        this.name = name;
        this.listid = listid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getListid() {
        return listid;
    }

    public void setListid(String listid) {
        this.listid = listid;
    }
}
