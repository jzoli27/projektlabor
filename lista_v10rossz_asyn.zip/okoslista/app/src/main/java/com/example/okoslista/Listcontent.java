package com.example.okoslista;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.okoslista.modells.Product;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.regex.Pattern;

public class Listcontent extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    RecyclerView recyclerView;
    Listitemadapter listitemadapter;

    private AlertDialog.Builder builder;
    private AlertDialog dialog;
    private EditText sharedemail;
    private Button save,cancel;
    private String listid,listname;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listcontent);

        recyclerView = findViewById(R.id.listItemRv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        listid = getIntent().getStringExtra("listid");
        listname = getIntent().getStringExtra("name");

        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(FirebaseDatabase.getInstance().getReference("Lists").child(listid).child("Products"), Product.class)
                        .build();


        listitemadapter = new Listitemadapter(options);
        recyclerView.setAdapter(listitemadapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        listitemadapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        listitemadapter.stopListening();
    }

    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.edit:
                Toast.makeText(Listcontent.this, "Szerkesztesre kattintottal", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.share:
                //Toast.makeText(Listcontent.this, "Megosztasra kattintottal", Toast.LENGTH_SHORT).show();
                createNewContactDialog();
                return true;

            default:
                return false;
        }
    }

    public void createNewContactDialog(){
        builder = new AlertDialog.Builder(this);
        final View PopupView = getLayoutInflater().inflate(R.layout.popup,null);

        sharedemail = (EditText) PopupView.findViewById(R.id.sharedemailEt);
        save = (Button) PopupView.findViewById(R.id.saveBtn);
        cancel = (Button) PopupView.findViewById(R.id.cancelBtn);

        builder.setView(PopupView);
        dialog = builder.create();
        dialog.show();

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //itt kell menteni adatbázisba
                String email = sharedemail.getText().toString();
                String permissionID = ""+System.currentTimeMillis();

                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("name",""+listname);
                hashMap.put("listid",""+listid);

                String[] parts = email.split(Pattern.quote("."));
                String email1 = parts[0];
                String email2 = parts[1];

                DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference("Permission");

                ref2.child(email1).child(listid).setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(Listcontent.this, "Sikeres hozzáadás", Toast.LENGTH_SHORT).show();
                            dialog.dismiss();
                        }
                    }
                });

            }
        });

        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
    }
}