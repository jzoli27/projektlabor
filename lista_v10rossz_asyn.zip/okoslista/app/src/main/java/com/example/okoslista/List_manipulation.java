package com.example.okoslista;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

import com.example.okoslista.modells.Listmodell;
import com.example.okoslista.modells.Usermodell;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class List_manipulation extends AppCompatActivity implements Listadapter.OnNoteListener {
    FloatingActionButton newlistbtn;

    RecyclerView listrecyclerview;
    DatabaseReference database;
    Listadapter listadapter;
    ArrayList<Listmodell> list;
    ArrayList<String> permission;
    ArrayList<String> sharedwithemail;
    int listSize;
    private String email;
    String key;
    String[] parts;
    String hello;
    String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_manipulation);

        listrecyclerview = findViewById(R.id.listRv);
        listrecyclerview.setHasFixedSize(true);
        listrecyclerview.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        permission = new ArrayList<>();
        sharedwithemail = new ArrayList<>();

        listadapter = new Listadapter(this,list,this);
        listrecyclerview.setAdapter(listadapter);




        /*
        readFirebaseName(new FirebaseCallback() {
            @Override
            public void onResponse(ArrayList<String> arrayList) {
                Log.d("TAG", arrayList.get(0));
                hello = arrayList.get(0);




            }
        });
        */

        // Kiszedem a bejelentkezett user email cimét
        /*
        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("email")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        email = snapshot.getValue(String.class);
                        Log.d("email",snapshot.getValue(String.class));
                        parts = email.split(Pattern.quote("."));
                        String email1 = parts[0];
                        String email2 = parts[1];
                        sharedwithemail.add(email1);
                        Log.d("csonk",email1);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

         */

        

        Log.d("hello",hello);
        //String[] parts = email.split(Pattern.quote("."));
        //String email1 = parts[0];
        //String email2 = parts[1];
        //Log.d("csonk",parts[0]);
        //FirebaseDatabase.getInstance().getReference(Permission)

        initLista();

        newlistbtn = findViewById(R.id.newlistBtn);

        newlistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(List_manipulation.this,Newlist.class));
            }
        });
    }

    @Override
    public void onNoteClick(int position) {
        //list.get(position);
        //Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        //startActivity(intent);
        String listid = list.get(position).getListid();
        String name = list.get(position).getName();
        Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        intent.putExtra("listid",listid);
        intent.putExtra("name", name);
        startActivity(intent);
        Log.d("teszt","onNoteClick is clicked. " + list.get(position).getName());
    }



    public void initLista(){
        FirebaseDatabase.getInstance().getReference("Lists").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Listmodell listmodell = dataSnapshot.getValue(Listmodell.class);
                    //if (listmodell.getListid().toString().equals("1636103468933") || listmodell.getListid().toString().equals("1636104235769")){
                    list.add(listmodell);
                    //}
                }
                listadapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void readFirebaseName(FirebaseCallback callback){
        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("email")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        email = snapshot.getValue(String.class);
                        Log.d("email",snapshot.getValue(String.class));
                        parts = email.split(Pattern.quote("."));
                        String email1 = parts[0];
                        String email2 = parts[1];
                        sharedwithemail.add(email1);
                        Log.d("csonk",email1);

                        callback.onResponse(sharedwithemail);
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
    }

    public interface FirebaseCallback {
        void onResponse(ArrayList<String> name);
    }

}
