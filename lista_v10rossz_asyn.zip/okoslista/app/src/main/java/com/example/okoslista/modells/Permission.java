package com.example.okoslista.modells;

public class Permission {
    private String email,permissionId;

    public Permission() {
    }

    public Permission(String email, String permissionId) {
        this.email = email;
        this.permissionId = permissionId;
    }

    public String getPermissionId() {
        return permissionId;
    }

    public void setPermissionId(String permissionId) {
        this.permissionId = permissionId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
