package com.example.okoslista;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.okoslista.modells.Listmodell;
import com.example.okoslista.modells.Permission;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class List_manipulation extends AppCompatActivity implements Listadapter.OnNoteListener {
    FloatingActionButton newlistbtn;

    RecyclerView listrecyclerview;
    DatabaseReference database;
    Listadapter listadapter;
    ArrayList<Listmodell> list;
    ArrayList<String> permission;
    ArrayList<String> sharedwithemail;
    int listSize;
    private String email;
    String key;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_manipulation);

        listrecyclerview = findViewById(R.id.listRv);
        //database = FirebaseDatabase.getInstance().getReference("Lists");
        listrecyclerview.setHasFixedSize(true);
        listrecyclerview.setLayoutManager(new LinearLayoutManager(this));

        list = new ArrayList<>();
        permission = new ArrayList<>();
        sharedwithemail = new ArrayList<>();

        listadapter = new Listadapter(this,list,this);
        listrecyclerview.setAdapter(listadapter);

        // Kiszedem az összes lista id-jét a permission arraylistbe
        FirebaseDatabase.getInstance().getReference("Permission").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Listmodell listmodell = dataSnapshot.getValue(Listmodell.class);
                    permission.add(listmodell.getListid());
                }
                int listSize = permission.size();

                for (int i = 0; i<listSize; i++){
                    Log.i("listaid: ", permission.get(i));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();


        FirebaseDatabase.getInstance().getReference("Users").child(uid).child("email")
                .addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        email = snapshot.getValue(String.class);
                        Log.d("email",snapshot.getValue(String.class));
                        Log.d("adat",String.valueOf(sharedwithemail.size()));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

        //for (int i = 0; i<permission.size(); i++){
            FirebaseDatabase.getInstance().getReference("Permission").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {

                    for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                        Listmodell listmodell = dataSnapshot.getValue(Listmodell.class);
                        String listaid = listmodell.getListid();
                        //Permission permissionmodell = dataSnapshot.getValue(Permission.class);
                        //if (permissionmodell.getEmail().equals(email)){
                        //    sharedwithemail.add(listmodell.getListid());
                        //}
                        key = snapshot.getKey();
                        Log.i("key", listaid);
                        DataSnapshot contentSnapshot = dataSnapshot.child(key);
                        Iterable<DataSnapshot> matchSnapShot = contentSnapshot.getChildren();
                        for (DataSnapshot match : matchSnapShot){
                            Permission perm = match.getValue(Permission.class);
                            sharedwithemail.add(perm.getEmail());
                            Log.i("kell", perm.getEmail());
                        }

                        /*
                        FirebaseDatabase.getInstance().getReference("Permission").child(key).addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot2) {
                                for (DataSnapshot dataSnapshot2 : snapshot2.getChildren()) {
                                    Permission perm = dataSnapshot2.getValue(Permission.class);
                                    //sharedwithemail.add(key.toString());
                                    Log.i("kell", snapshot2.getKey());
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });*/
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        //}

        initLista();

        newlistbtn = findViewById(R.id.newlistBtn);

        newlistbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(List_manipulation.this,Newlist.class));
            }
        });
    }

    @Override
    public void onNoteClick(int position) {
        //list.get(position);
        //Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        //startActivity(intent);
        String listid = list.get(position).getListid();
        Intent intent = new Intent(List_manipulation.this,Listcontent.class);
        intent.putExtra("listid",listid);
        startActivity(intent);
        Log.d("teszt","onNoteClick is clicked. " + list.get(position).getName());
    }

    public void initLista(){
        FirebaseDatabase.getInstance().getReference("Lists").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot dataSnapshot : snapshot.getChildren()){
                    Listmodell listmodell = dataSnapshot.getValue(Listmodell.class);
                    list.add(listmodell);
                }
                listadapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}
