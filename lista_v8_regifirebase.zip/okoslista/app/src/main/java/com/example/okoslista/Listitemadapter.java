package com.example.okoslista;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.okoslista.modells.Product;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class Listitemadapter extends FirebaseRecyclerAdapter<Product,Listitemadapter.myViewHolder> {


    public Listitemadapter(@NonNull FirebaseRecyclerOptions<Product> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull myViewHolder holder, int position, @NonNull Product model) {
        holder.name.setText(model.getName());
        holder.quantity.setText(model.getQuantity()+" db");
        holder.price.setText(model.getPrice()+" Ft");
        //holder.checkBox.setText(model.getState());

    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.listitem,parent,false);
        return new myViewHolder(v);
    }

    class myViewHolder extends RecyclerView.ViewHolder{

        TextView name;
        EditText quantity,price;
        CheckBox checkBox;

        public myViewHolder(@NonNull View itemView) {
            super(itemView);

            name =(TextView) itemView.findViewById(R.id.productTv);
            quantity = (EditText)itemView.findViewById(R.id.quantityEt);
            price = (EditText)itemView.findViewById(R.id.priceEt);
            checkBox = (CheckBox)itemView.findViewById(R.id.itemCheckbox);
        }
    }
}
