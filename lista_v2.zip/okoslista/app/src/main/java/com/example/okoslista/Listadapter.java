package com.example.okoslista;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.okoslista.modells.Listmodell;

import java.util.ArrayList;

public class Listadapter extends RecyclerView.Adapter <Listadapter.MyViewHolder> {

    Context context;
    ArrayList<Listmodell> list;

    public Listadapter(Context context, ArrayList<Listmodell> list) {
        this.context = context;
        this.list = list;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.listelem,parent,false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        Listmodell listmodell = list.get(position);
        holder.listname.setText(listmodell.getName());
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView listname;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);

            listname = itemView.findViewById(R.id.tvlistname);
        }
    }

}
