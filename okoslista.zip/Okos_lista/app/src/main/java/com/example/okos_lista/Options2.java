package com.example.okos_lista;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Options2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options2);
    }
}