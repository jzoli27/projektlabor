package com.example.okos_lista;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private EditText emailEt,passwordeT;
    private Button loginbtn;
    private TextView forgotpw;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        emailEt = findViewById(R.id.emailEt_login);
        passwordeT = findViewById(R.id.passwordEt_login);
        loginbtn = findViewById(R.id.loginBtn);
        forgotpw = findViewById(R.id.forgotpasswordTv);

        mAuth = FirebaseAuth.getInstance();

        forgotpw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,Registration.class));
            }
        });

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginUser();
            }
        });
    }

    private void loginUser() {
        String email = emailEt.getText().toString();
        String password = passwordeT.getText().toString();

        if (TextUtils.isEmpty(email)){
            emailEt.setText("Nem lehet üres az email!");
            emailEt.requestFocus();
        }else if (TextUtils.isEmpty(password)){
            passwordeT.setText("Nem lehet üres a jelszó!");
            passwordeT.requestFocus();
        }else{
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()){
                        Toast.makeText(MainActivity.this, "Sikeres bejelentkezés", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(MainActivity.this,List_manipulation.class));
                    }else {
                        Toast.makeText(MainActivity.this, "Sikertelen bejelentkezés", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }
    }
}