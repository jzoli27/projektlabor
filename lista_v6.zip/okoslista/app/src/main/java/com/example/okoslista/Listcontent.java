package com.example.okoslista;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.example.okoslista.modells.Product;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Listcontent extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {
    RecyclerView recyclerView;
    Listitemadapter listitemadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listcontent);

        recyclerView = findViewById(R.id.listItemRv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        String listid = getIntent().getStringExtra("listid");

        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(FirebaseDatabase.getInstance().getReference("Lists").child(listid).child("Products"), Product.class)
                        .build();


        listitemadapter = new Listitemadapter(options);
        recyclerView.setAdapter(listitemadapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        listitemadapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        listitemadapter.stopListening();
    }

    public void showPopup(View v){
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.popup_menu);
        popup.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.edit:
                Toast.makeText(Listcontent.this, "Szerkesztesre kattintottal", Toast.LENGTH_SHORT).show();
                return true;

            case R.id.share:
                Toast.makeText(Listcontent.this, "Megosztasra kattintottal", Toast.LENGTH_SHORT).show();
                return true;

            default:
                return false;
        }
    }
}