package com.example.okoslista;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.okoslista.modells.Usermodell;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Newlist extends AppCompatActivity {
    EditText newlistname;
    Button createListbtn;

    FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_newlist);

        newlistname = findViewById(R.id.newlistEt);
        createListbtn = findViewById(R.id.createListBtn);

        createListbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String listID = ""+System.currentTimeMillis();
                String listname = newlistname.getText().toString();

                DatabaseReference ref = FirebaseDatabase.getInstance().getReference("Lists");
                HashMap<String, Object> hashMap = new HashMap<>();
                hashMap.put("name",""+listname);
                hashMap.put("listid",""+listID);
                ref.child(listID).setValue(hashMap);



                String uid = FirebaseAuth.getInstance().getCurrentUser().getUid().toString();

               FirebaseDatabase.getInstance().getReference("Users").child(uid).child("email")
                        .addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {
                                Log.d("email",snapshot.getValue(String.class));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });


                FirebaseDatabase.getInstance().getReference("Users").child(uid).addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        Usermodell userProfile = snapshot.getValue(Usermodell.class);

                        if (userProfile != null){
                            String email = userProfile.getEmail();
                            String permissionID = ""+System.currentTimeMillis();

                            HashMap<String, Object> hashMap = new HashMap<>();
                            hashMap.put("email",""+email);
                            hashMap.put("permissionId",""+permissionID);

                            DatabaseReference ref2 = FirebaseDatabase.getInstance().getReference("Permission");
                            ref2.child(listID).setValue(hashMap);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });


    }
}