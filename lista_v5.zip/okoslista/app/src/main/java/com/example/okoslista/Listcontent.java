package com.example.okoslista;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import com.example.okoslista.modells.Product;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;

public class Listcontent extends AppCompatActivity {
    RecyclerView recyclerView;
    Listitemadapter listitemadapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listcontent);

        recyclerView = findViewById(R.id.listItemRv);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        String listid = getIntent().getStringExtra("listid");

        FirebaseRecyclerOptions<Product> options =
                new FirebaseRecyclerOptions.Builder<Product>()
                        .setQuery(FirebaseDatabase.getInstance().getReference("Lists").child(listid).child("Products"), Product.class)
                        .build();


        listitemadapter = new Listitemadapter(options);
        recyclerView.setAdapter(listitemadapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        listitemadapter.startListening();
    }

    @Override
    protected void onStop() {
        super.onStop();
        listitemadapter.stopListening();
    }
}