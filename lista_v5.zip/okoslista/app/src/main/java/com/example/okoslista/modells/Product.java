package com.example.okoslista.modells;

public class Product {
    private String name,category,price,quantity,productid,state;

    public Product() {
    }

    public Product(String name, String category, String price, String quantity,String productid,String state) {
        this.name = name;
        this.category = category;
        this.price = price;
        this.quantity = quantity;
        this.productid = productid;
        this.state = state;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getProductid() {
        return productid;
    }

    public void setProductid(String productid) {
        this.productid = productid;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
